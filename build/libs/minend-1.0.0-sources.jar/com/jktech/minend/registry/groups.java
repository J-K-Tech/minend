package com.jktech.minend.registry;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2960;

public class groups{
    public static final class_1761 MINEND_MATERIALS = FabricItemGroupBuilder.build(
            new class_2960("minend", "materials"),
            () -> new class_1799(class_2246.field_10445)
    );
    public static final class_1761 MINEND_WEAPONS = FabricItemGroupBuilder.build(
            new class_2960("minend", "weapons"),
            () -> new class_1799(class_1802.field_8371)
    );
    public static final class_1761 MINEND_LOOTS = FabricItemGroupBuilder.build(
            new class_2960("minend", "loots"),
            () -> new class_1799(class_1802.field_27023)
    );
    public static final class_1761 MINEND_TOOLS = FabricItemGroupBuilder.build(
            new class_2960("minend", "tools"),
            () -> new class_1799(class_1802.field_8609)
    );
}
