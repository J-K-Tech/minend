package com.jktech.minend.registry;

import com.jktech.minend.Initi;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;


public class items {
//organic materials
    public static final class_1792 RESIN = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_MATERIALS));
    public static final class_1792 PLASTIC = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_MATERIALS));
//inorganic materials
//tools
    public static final class_1792 SAMPLE_TOOL = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_TOOLS));

//weapons
    public static final class_1792 KNIFE = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_WEAPONS));

//loots
    //packs
    public static final class_1792 TINY_PACK = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_LOOTS));
    public static final class_1792 MEDIUM_PACK = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_LOOTS));
    public static final class_1792 BIG_PACK = new class_1792(new class_1792.class_1793().method_7892(groups.MINEND_LOOTS));

    public static void registerItems(){
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "resin"),RESIN);
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "plastic"),PLASTIC);
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "knife"),KNIFE);
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "tiny pack"),TINY_PACK);
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "medium pack"),MEDIUM_PACK);
        class_2378.method_10230(class_2378.field_11142, new class_2960(Initi.MOD_ID, "big pack"),BIG_PACK);
    }
}
