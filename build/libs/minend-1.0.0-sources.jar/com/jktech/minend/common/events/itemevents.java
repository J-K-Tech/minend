package com.jktech.minend.common.events;
import com.jktech.minend.registry.items;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(class_1542.class)
public abstract class itemevents extends class_1542 {
    public itemevents(class_1299<? extends class_1542> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Inject(at = @At("HEAD"), method = "damage")
    public boolean method_5643(class_1282 source, float amount) {
        if (this.method_6983().method_31574(items.RESIN) && source.method_5534()) {
        this.method_6979(new class_1799(items.RESIN));
        return true;}
        else {return false;}

    }
}